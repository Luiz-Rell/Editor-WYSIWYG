﻿using System.ComponentModel.DataAnnotations;

namespace DocumentoWebApi.Models
{
    public class SolicitarRecuperacaoRequest
    {
        [Required]
        [EmailAddress]
        [MinLength(6, ErrorMessage = "É Necessário colocar um e-mail para que você possa fazer a recuperação de sua senha.")]
        public string Email { get; set; }
    }
}
