﻿using System.ComponentModel.DataAnnotations.Schema;

namespace DocumentacaoWebApi.Models
{
    [Table("Papeis", Schema = "core")]
    public class Papel
    {
        [Column("id")]
        public int Id { get; set; }

        [Column("nome")]
        public string Nome { get; set; }

        [Column("descricao")]
        public string? Descricao { get; set; }
    }
}