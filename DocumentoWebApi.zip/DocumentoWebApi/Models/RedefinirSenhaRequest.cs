﻿using System.ComponentModel.DataAnnotations;
namespace DocumentacaoWebApi.Models;

public class RedefinirSenhaRequest
{
    [Required] public string Token { get; set; }
    [Required][MinLength(6)] public string NovaSenha { get; set; }
}