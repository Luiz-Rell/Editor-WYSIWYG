﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

namespace DocumentacaoWebApi.Models
{
    [Table("Usuarios", Schema = "core")]
    public class Usuario
    {
        [Column("id")]
        public int Id { get; set; }

        [Column("nome_completo")]
        public string NomeCompleto { get; set; }

        [Column("email")]
        public string Email { get; set; }

        [Column("senha_hash")]
        public string SenhaHash { get; set; }

        [Column("cargo")]
        public string? Cargo { get; set; }

        [Column("status")]
        public string Status { get; set; }

        [Column("data_criacao")]
        public DateTime DataCriacao { get; set; }

        [Column("data_atualizacao")]
        public DateTime DataAtualizacao { get; set; }

        [Column("TokenRecuperacao")]
        public string? TokenRecuperacao { get; set; }

        [Column("TokenRecuperacaoExpiracao")]
        public DateTime? TokenRecuperacaoExpiracao { get; set; }

        public virtual ICollection<UsuarioPapeis> UsuarioPapeis { get; set; } = new List<UsuarioPapeis>();
    }
}