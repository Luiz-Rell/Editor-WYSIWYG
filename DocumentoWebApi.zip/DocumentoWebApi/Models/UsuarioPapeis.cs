﻿using System.ComponentModel.DataAnnotations.Schema; // Adicione este using

namespace DocumentacaoWebApi.Models
{
    public class UsuarioPapeis
    {
        // Mapeia a propriedade UsuarioId para a coluna usuario_id
        [Column("usuario_id")]
        public int UsuarioId { get; set; }
        public Usuario Usuario { get; set; }

        // Mapeia a propriedade PapelId para a coluna papel_id
        [Column("papel_id")]
        public int PapelId { get; set; }
        public Papel Papel { get; set; }
    }
}