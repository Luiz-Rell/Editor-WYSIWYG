﻿using System.ComponentModel.DataAnnotations.Schema; // Garanta que este 'using' existe

namespace DocumentacaoWebApi.Models
{
    // Garanta que esta anotação [Table] existe
    [Table("Documentos", Schema = "core")]
    public class Documento
    {
        // Garanta que a anotação [Column("id")] existe
        [Column("id")]
        public int Id { get; set; }

        [Column("titulo")]
        public string Titulo { get; set; }

        [Column("conteudo")]
        public string Conteudo { get; set; }

        [Column("autor_id")]
        public int? AutorId { get; set; }

        [Column("status")]
        public string Status { get; set; }

        [Column("data_criacao")]
        public DateTime DataCriacao { get; set; }

        [Column("data_publicacao")]
        public DateTime? DataPublicacao { get; set; }

        public Usuario? Autor { get; set; }
    }
}