﻿using DocumentacaoWebApi.Models;
using Microsoft.EntityFrameworkCore;

namespace DocumentacaoWebApi.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Papel> Papeis { get; set; }
        public DbSet<UsuarioPapeis> UsuarioPapeis { get; set; }
        public DbSet<Documento> Documentos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<UsuarioPapeis>()
                .HasKey(up => new { up.UsuarioId, up.PapelId });

            modelBuilder.Entity<UsuarioPapeis>()
                .HasOne(up => up.Usuario)
                // AQUI ESTÁ A CORREÇÃO: Especificamos a propriedade de navegação
                .WithMany(u => u.UsuarioPapeis)
                .HasForeignKey(up => up.UsuarioId);

            modelBuilder.Entity<UsuarioPapeis>()
                .HasOne(up => up.Papel)
                .WithMany()
                .HasForeignKey(up => up.PapelId);

            modelBuilder.Entity<UsuarioPapeis>()
                .ToTable("UsuarioPapeis", "core");

            modelBuilder.Entity<Documento>()
                .ToTable("Documentos", "core");

            modelBuilder.Entity<Usuario>()
                .Property(u => u.DataCriacao)
                .HasDefaultValueSql("GETDATE()");

            modelBuilder.Entity<Usuario>()
                .Property(u => u.DataAtualizacao)
                .HasDefaultValueSql("GETDATE()");
        }
    }
}