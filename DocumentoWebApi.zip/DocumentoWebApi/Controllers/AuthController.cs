﻿using DocumentacaoWebApi.Data;
using DocumentacaoWebApi.Models;
using DocumentoWebApi.Models;
using MailKit.Security;
using MailKit.Net.Smtp;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using MimeKit;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;


namespace DocumentacaoWebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        // --- INJEÇÃO DE DEPENDÊNCIAS ---
        private readonly ApplicationDbContext _context;
        private readonly IConfiguration _configuration;
        private readonly ILogger<AuthController> _logger;

        // --- CONSTRUTOR ---

        /// <summary>
        /// Recebe o contexto do banco de dados e a configuração da aplicação para inicializar o controlador de autenticação.
        /// </summary>
        public AuthController(ApplicationDbContext context, IConfiguration configuration, ILogger<AuthController> logger)
        {
            _context = context;
            _configuration = configuration;
            _logger = logger;
        }

        // --- ENDPOINTS DE AUTENTICAÇÃO ---

        /// <summary>
        /// Endpoint para o login de usuários.
        /// Realiza a autenticação do usuário e retorna um token JWT se as credenciais estiverem corretas.
        /// </summary>
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest loginRequest)
        {

            // Verifica se o corpo da requisição contém os campos necessários
            if (string.IsNullOrEmpty(loginRequest.Email) || string.IsNullOrEmpty(loginRequest.Senha))
            {
                return BadRequest(new { message = "E-mail e senha são obrigatórios." });
            }


            // Verifica se o e-mail é válido
            try
            {
                var usuario = await _context.Usuarios
                .Include(u => u.UsuarioPapeis)
                    .ThenInclude(up => up.Papel)
                .FirstOrDefaultAsync(u => u.Email == loginRequest.Email);

                if (usuario == null || !BCrypt.Net.BCrypt.Verify(loginRequest.Senha, usuario.SenhaHash))
                {
                    _logger.LogWarning("Tentativa de login falhou para o e-mail: {Email}", loginRequest.Email);
                    return Unauthorized(new { message = "E-mail ou senha inválidos." });
                }
                var papelId = usuario.UsuarioPapeis.FirstOrDefault()?.Papel?.Id ?? 99;

                // Passamos o ID do papel para o gerador de token
                var token = GenerateJwtToken(usuario, papelId);
                _logger.LogInformation("Usuário {Email} logou com sucesso com o papel ID: {PapelId}", usuario.Email, papelId);

                return Ok(new { token = token, message = "Login bem-sucedido!" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ocorreu uma exceção não tratada no método Login para o e-mail {Email}", loginRequest.Email);

                Console.WriteLine($"Ocorreu um erro inesperado no login: {ex.Message}");
                // Se quiser ver o caminho completo do erro, descomente a linha abaixo:
                // Console.WriteLine(ex.StackTrace);
                return StatusCode(500, new { message = "Ocorreu um erro interno no servidor." });
            }
        }

        private IActionResult Forbid(object value)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Endpoint para o registro de novos usuários.
        /// Cria um novo usuário no sistema com o papel padrão "Leitor".
        /// </summary>
        [HttpPost("registrar")]
        public async Task<IActionResult> Registrar([FromBody] RegistroRequest registroRequest)
        {
            // Valida os dados recebidos
            // Verifica se o corpo da requisição contém os campos necessários
            // Se algum campo obrigatório estiver faltando, retorna BadRequest com a mensagem apropriada
            // Usa ModelState para validar os dados com base nas anotações de dados
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Verifica se o e-mail tem o domínio correto
            // Permite apenas e-mails com o domínio @comm.tec.br
            // Se o domínio for inválido, retorna BadRequest com a mensagem apropriada
            if (!registroRequest.Email.EndsWith("@comm.tec.br", StringComparison.OrdinalIgnoreCase))
            {
                return BadRequest(new { message = "Cadastro permitido apenas para e-mails com o domínio @comm.tec.br." });
            }

            // Verifica se o e-mail já está em uso
            // Usando FirstOrDefaultAsync para buscar o usuário com o e-mail fornecido
            // Se encontrar, retorna um conflito
            var usuarioExistente = await _context.Usuarios.FirstOrDefaultAsync(u => u.Email == registroRequest.Email);
            if (usuarioExistente != null)
            {
                _logger.LogWarning("Tentativa de registro para e-mail já existente: {Email}", registroRequest.Email);

                return Conflict(new { message = "Este e-mail já está cadastrado." });
            }

            // Cria o novo usuário
            // Usa BCrypt para hash da senha antes de armazená-la
            var senhaHash = BCrypt.Net.BCrypt.HashPassword(registroRequest.Senha);

            // Cria a entidade do usuário
            // Define o status inicial como "ativo"
            var novoUsuario = new Usuario
            {
                NomeCompleto = registroRequest.NomeCompleto,
                Email = registroRequest.Email,
                SenhaHash = senhaHash,
                Cargo = registroRequest.Cargo,
                Status = "Ativo"
            };

            // Adiciona o novo usuário ao contexto e salva as mudanças
            _context.Usuarios.Add(novoUsuario);
            await _context.SaveChangesAsync();


            // Atribui o papel padrão "Leitor" ao novo usuário
            // Busca o papel "Leitor" no banco de dados
            // Se encontrado, cria a associação entre o usuário e o papel
            var papelLeitor = await _context.Papeis.FirstOrDefaultAsync(p => p.Nome == "Leitor");
            if (papelLeitor != null)
            {
                var novoUsuarioPapel = new UsuarioPapeis
                {
                    UsuarioId = novoUsuario.Id,
                    PapelId = papelLeitor.Id
                };
                _context.UsuarioPapeis.Add(novoUsuarioPapel);
                await _context.SaveChangesAsync();
            }
            else
            {
                _logger.LogError("Papel 'Leitor' não encontrado no banco de dados durante o registro do usuário {Email}.", novoUsuario.Email);

                // Log de erro real no console do servidor
                Console.WriteLine("Papel 'Leitor' não encontrado no banco de dados.");
                // Retorno de um erro genérico para o cliente
                return StatusCode(500, new { message = "Ocorreu um erro interno no servidor." });
            }
            _logger.LogInformation("Novo usuário registrado com sucesso: {Email}", novoUsuario.Email);
            return Ok(new { message = "Usuário criado com sucesso! Você já pode fazer o login." });
        }

        /// <summary>
        /// Endpoint para solicitar a recuperação de senha.
        /// Envia um e-mail com um link de recuperação se o e-mail estiver cadastrado.
        /// </summary>
        [HttpPost("solicitar-recuperacao")]
        public async Task<IActionResult> SolicitarRecuperacao([FromBody] SolicitarRecuperacaoRequest request)
        {
            // Verifica se o corpo da requisição contém o e-mail
            var usuario = await _context.Usuarios.FirstOrDefaultAsync(u => u.Email == request.Email);

            // Se o usuário não for encontrado, não retorna erro para evitar vazamento de informações
            if (usuario != null)
            {
                usuario.TokenRecuperacao = Guid.NewGuid().ToString();
                usuario.TokenRecuperacaoExpiracao = DateTime.UtcNow.AddMinutes(30);
                await _context.SaveChangesAsync();

                var link = $"http://127.0.0.1:5500/redefinir-senha.html?token={usuario.TokenRecuperacao}";
                var corpoEmail = $"<p>Olá, {usuario.NomeCompleto},</p><p>Clique no link a seguir para redefinir sua senha: <a href='{link}'>Redefinir Senha</a></p>";
                await EnviarEmailAsync(usuario.Email, "Recuperação de Senha", corpoEmail);
            }

            return Ok(new { message = "Se um e-mail associado a esta conta existir, um link de recuperação foi enviado." });
        }

        /// <summary>
        /// Endpoint para redefinir a senha do usuário.
        /// Recebe um token de recuperação e a nova senha.
        /// Redefine a senha se o token for válido.
        /// </summary>
        [HttpPost("redefinir-senha")]
        public async Task<IActionResult> RedefinirSenha([FromBody] RedefinirSenhaRequest request)
        {
            var usuario = await _context.Usuarios.FirstOrDefaultAsync(u =>
                u.TokenRecuperacao == request.Token && u.TokenRecuperacaoExpiracao > DateTime.UtcNow);

            if (usuario == null)
            {
                return BadRequest(new { message = "Token inválido ou expirado." });
            }

            // Verifica se a nova senha atende aos requisitos mínimos
            // Se a nova senha for nula ou tiver menos de 6 caracteres, retorna BadRequest
            if (string.IsNullOrEmpty(request.NovaSenha) || request.NovaSenha.Length < 6)
            {
                return BadRequest(new { message = "A nova senha deve ter pelo menos 6 caracteres." });
            }

            // Redefine a senha do usuário
            // Usa BCrypt para hash da nova senha antes de armazená-la
            // Limpa o token de recuperação e sua expiração
            // Após redefinir a senha, limpa o token de recuperação e sua expiração
            usuario.SenhaHash = BCrypt.Net.BCrypt.HashPassword(request.NovaSenha);
            usuario.TokenRecuperacao = null;
            usuario.TokenRecuperacaoExpiracao = null;
            await _context.SaveChangesAsync();

            return Ok(new { message = "Senha redefinida com sucesso!" });
        }

        // --- MÉTODOS PRIVADOS AUXILIARES ---

        /// <summary>
        /// Gera um token JWT para o usuário autenticado.
        /// Inclui o e-mail e o ID do usuário como claims.
        /// O token expira em 8 horas.
        /// </summary>
        private string GenerateJwtToken(Usuario usuario, int papelId)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
    {
        new Claim(JwtRegisteredClaimNames.Sub, usuario.Email),
        new Claim("userid", usuario.Id.ToString()),
        // --- MUDANÇA AQUI ---
        // Adicionamos o papelId como uma claim. O valor tem de ser string.
        new Claim("papelId", papelId.ToString())
    };

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddHours(8),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        /// <summary>
        /// Envia um e-mail usando o MailKit.
        /// </summary>
        private async Task EnviarEmailAsync(string emailDestino, string assunto, string corpoHtml)
        {
            // Substitua com seus dados reais de servidor SMTP
            var email = new MimeMessage();
            email.From.Add(new MailboxAddress("Sistema de Documentação", "nao-responda@comm.tec.br"));
            email.To.Add(new MailboxAddress("", emailDestino));
            email.Subject = assunto;
            email.Body = new BodyBuilder { HtmlBody = corpoHtml }.ToMessageBody();

            using (var smtp = new SmtpClient())
            {
                // ATENÇÃO: Use User Secrets para dados sensíveis em produção.
                await smtp.ConnectAsync("\r\nsmtp.hostinger.com", 587, SecureSocketOptions.StartTls);
                await smtp.AuthenticateAsync("seu-email@example.com", "sua-senha");
                await smtp.SendAsync(email);
                await smtp.DisconnectAsync(true);
            }
        }
    }
}