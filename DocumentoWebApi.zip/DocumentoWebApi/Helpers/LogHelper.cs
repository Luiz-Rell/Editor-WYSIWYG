﻿using Microsoft.Extensions.Logging; // Usando a interface padrão do .NET

namespace DocumentacaoWebApi.Helpers
{
    public static class LogHelper
    {
        public static void SendLog(ILogger logger, bool isDebug, string message, int level = 1)
        {
            // Sua lógica: só loga se isDebug for true OU se o nível for de Erro (3)
            if (isDebug || level == 3)
            {
                switch (level)
                {
                    case 0: // Debug
                        logger.LogDebug(message);
                        break;
                    case 1: // Info
                        logger.LogInformation(message);
                        break;
                    case 2: // Warning
                        logger.LogWarning(message);
                        break;
                    case 3: // Error
                        // Para erros, é melhor passar a exceção também, se houver
                        logger.LogError(message);
                        break;
                    default:
                        logger.LogError("Nível de log inválido fornecido para a mensagem: {message}", message);
                        break;
                }
            }
        }

        // Uma versão sobrecarregada para incluir exceções
        public static void SendLog(ILogger logger, bool isDebug, Exception ex, string message, int level = 3)
        {
            if (isDebug || level == 3)
            {
                // Para o nível de erro, sempre usamos LogError
                logger.LogError(ex, message);
            }
        }
    }
}