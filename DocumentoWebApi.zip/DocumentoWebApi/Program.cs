using DocumentacaoWebApi.Data;
using Microsoft.EntityFrameworkCore;
using NLog.Web;


// --- IN�CIO DA CONFIGURA��O DO NLOG ---
var builder = WebApplication.CreateBuilder(args);

// Limpa os provedores de log padr�o
//builder.Logging.ClearProviders();

// Habilita o NLog como o provedor de log
builder.Host.UseNLog();


// --- Configura��o dos Servi�os ---
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddControllers();

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowWebApp",
        builder => builder.WithOrigins("http://127.0.0.1:5500", "http://localhost:5500") // <- Deve conter a origem do erro
                          .AllowAnyHeader()
                          .AllowAnyMethod());
});

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// --- Constru��o da Aplica��o ---
var app = builder.Build();

// --- Configura��o do Pipeline HTTP ---
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// ORDEM CORRETA E RECOMENDADA
app.UseRouting(); // 1. Define as rotas primeiro

app.UseCors("AllowWebApp"); // 2. Aplica a pol�tica de CORS

app.UseAuthorization(); // 3. Aplica a autoriza��o

app.MapControllers(); // 4. Mapeia os controllers para as rotas

app.Run();
